const Option = require('../model/Option');

// const JDate = require('jalali-date');

const saveData = async (req, res) => {
    const resultFilter = req.body;

    const newOption = new Option;

    newOption.name=resultFilter.name;
    newOption.isin=resultFilter.isin;
    newOption.ic=resultFilter.ic;
    newOption.hoqBuy=resultFilter.hoqBuy;
    newOption.haqBuy=resultFilter.haqBuy;
    newOption.hoqSell=resultFilter.hoqSell;
    newOption.haqSell=resultFilter.haqSell;
    newOption.ppercent=resultFilter.ppercent;
    newOption.pprice=resultFilter.pprice;
    newOption.lprice=resultFilter.lprice;
    newOption.lpercent=resultFilter.lpercent;
    newOption.vol=resultFilter.vol;
    newOption.openPositions=resultFilter.openPositions;
    newOption.days=resultFilter.days;
    newOption.emal=resultFilter.emal;
    newOption.situation=resultFilter.situation;
    newOption.firstSell=resultFilter.firstSell;
    newOption.firstBuy=resultFilter.firstBuy;
    newOption.orders=resultFilter.orders;
    newOption.minPrice=resultFilter.minPrice;
    newOption.maxPrice=resultFilter.maxPrice;
    newOption.yesterday=resultFilter.yesterday;
    newOption.contractSize=resultFilter.contractSize;
    newOption.saraneBuyV=resultFilter.saraneBuyV;
    newOption.saraneSellV=resultFilter.saraneSellV;
    newOption.saraneBuyP=resultFilter.saraneBuyP;
    newOption.saraneSellP=resultFilter.saraneSellP;
    newOption.Bpercent=resultFilter.Bpercent;
    newOption.Spercent=resultFilter.Spercent;
    newOption.minpercent=resultFilter.minpercent;
    newOption.maxpercent=resultFilter.maxpercent;
    newOption.sarBEsariPriceS=resultFilter.sarBEsariPriceS;
    newOption.sarBEsariPriceB=resultFilter.sarBEsariPriceB;
    newOption.sarBEsariPriceL=resultFilter.sarBEsariPriceL;
    newOption.sarBEsariPercentS=resultFilter.sarBEsariPercentS;
    newOption.sarBEsariPercentB=resultFilter.sarBEsariPercentB;
    newOption.sarBEsariPercentL=resultFilter.sarBEsariPercentL;
    newOption.sarBEsariDaily=resultFilter.sarBEsariDaily;
    newOption.pooshesh=resultFilter.pooshesh;
    newOption.ahromS=resultFilter.ahromS;
    newOption.ahromB=resultFilter.ahromB;
    newOption.ahromL=resultFilter.ahromL;
    newOption.base=resultFilter.base;
    newOption.month=resultFilter.month;
    newOption.baseIsin=resultFilter.baseIsin;
    newOption.groupId=resultFilter.groupId;
    newOption.bazar=resultFilter.bazar;
    newOption.tazmin=resultFilter.tazmin;
    newOption.inSood=resultFilter.inSood;
    newOption.Delta=resultFilter.Delta;
    newOption.Theta=resultFilter.Theta;
    newOption.Rho=resultFilter.Rho;
    newOption.Gamma=resultFilter.Gamma;
    newOption.Vega=resultFilter.Vega;
    newOption.Black=resultFilter.Black;
    newOption.coveredCall=resultFilter.coveredCall;
    newOption.coveredCall_m=resultFilter.coveredCall_m;
    newOption.coveredCall_y=resultFilter.coveredCall_y;

    newOption.save();
}


const getAllOptions = async (req, res) => {
    const options = await Option.find();
    if (!options) return res.status(204).json({ 'message': 'No option found' });
    res.json(options);
}

const getSortOptions = async (req, res) => {
    const { settings } = req.body;

    // const jdate = new JDate;
    // const jdate = new JDate.toJalali(new Date("2024,04,24"))
    // console.log(jdate)

    const optionsTotal = await Option.findOne();
    if (!optionsTotal) return res.status(204).json({ 'message': 'No option found' });
    
    var Parameters = Array.from(Array(12), () => new Array(1));
    var Index = Array.from(Array(12), () => new Array(1));
    var nFilter = 12;

    Parameters[0]=optionsTotal.vol;
    Parameters[1]=optionsTotal.lpercent;
    Parameters[2]=optionsTotal.lprice;
    Parameters[3]=optionsTotal.ahromS;
    Parameters[4]=optionsTotal.emal;
    Parameters[5]=optionsTotal.days;
    Parameters[6]=optionsTotal.openPositions;
    Parameters[7]=optionsTotal.ahromB;
    Parameters[8]=optionsTotal.haqBuy;
    Parameters[9]=optionsTotal.hoqBuy;
    // Parameters[10]=optionsTotal.sarBEsariPercentB;
    // Parameters[11]=optionsTotal.sarBEsariPercentS;

    optionName=optionsTotal.name;
    var nOption = Parameters[0].length;
    var selectedOptions=[];

    // for (let i=0; i<nFilter; i++)
    //     if (1)//soudi nozooli
    //         Index[i] = Array.from(Array(Parameters[i].length).keys()).sort((b, a) => Parameters[i][a] < Parameters[i][b] ? -1 : (Parameters[i][b] < Parameters[i][a]) | 0)


    for (let i=0; i<nFilter; i++){
        for (let j=0; j<Parameters[i].length; j++)
            Index[i][j]=Math.round(Math.random()*Parameters[i].length);
    }

    // filter output options
    var options=[];
    for(var param=0; param<nFilter; param++){
        var name=[];
        var value=[];
        
        for (var s in JSON.parse(settings)){
            if(JSON.parse(settings)[s].id === String("minF"+(param+1))){
                if (JSON.parse(settings)[s].value === '')
                    var min = 0;
                else
                    var min = JSON.parse(settings)[s].value;
            }
            if(JSON.parse(settings)[s].id === String("maxF"+(param+1))){
                if (JSON.parse(settings)[s].value === '')
                    var max = Infinity;
                else
                    var max = JSON.parse(settings)[s].value;
            }
        }

        for (let i=0; i<nOption; i++){
            let index = Index[param][i];
            if (Parameters[param][index] >= min && Parameters[param][index] <= max){
                name.push(optionName[Index[param][i]]);
                value.push(Parameters[param][Index[param][i]]);
                selectedOptions.push(Index[param][i]);
            }
            if (name.length>=10)
                break;
        }

        options[param]={
            name: name,
            value: value
        }
    }
    
    selectedOptions = selectedOptions.filter((e, i, a) => a.indexOf(e) === i);

    var params = Array.from(Array(58), () => new Array(1));

    selectedOptions.map((value)=>{
        params[0].push(optionsTotal.name[value]);
        params[1].push(optionsTotal.isin[value]);
        params[2].push(optionsTotal.ic[value]);
        params[3].push(optionsTotal.hoqBuy[value]);
        params[4].push(optionsTotal.haqBuy[value]);
        params[5].push(optionsTotal.hoqSell[value]);
        params[6].push(optionsTotal.haqSell[value]);
        params[7].push(optionsTotal.ppercent[value]);
        params[8].push(optionsTotal.pprice[value]);
        params[9].push(optionsTotal.lprice[value]);
        params[10].push(optionsTotal.lpercent[value]);
        params[11].push(optionsTotal.vol[value]);
        params[12].push(optionsTotal.openPositions[value]);
        params[13].push(optionsTotal.days[value]);
        params[14].push(optionsTotal.emal[value]);
        params[15].push(optionsTotal.situation[value]);
        params[16].push(optionsTotal.firstSell[value]);
        params[17].push(optionsTotal.firstBuy[value]);
        params[18].push(optionsTotal.orders[value]);
        params[19].push(optionsTotal.minPrice[value]);
        params[20].push(optionsTotal.maxPrice[value]);
        params[21].push(optionsTotal.yesterday[value]);
        params[22].push(optionsTotal.contractSize[value]);
        params[23].push(optionsTotal.saraneBuyV[value]);
        params[24].push(optionsTotal.saraneSellV[value]);
        params[25].push(optionsTotal.saraneBuyP[value]);
        params[26].push(optionsTotal.saraneSellP[value]);
        params[27].push(optionsTotal.Bpercent[value]);
        params[28].push(optionsTotal.Spercent[value]);
        params[29].push(optionsTotal.minpercent[value]);
        params[30].push(optionsTotal.maxpercent[value]);
        params[31].push(optionsTotal.sarBEsariPriceS[value]);
        params[32].push(optionsTotal.sarBEsariPriceB[value]);
        params[33].push(optionsTotal.sarBEsariPriceL[value]);
        params[34].push(optionsTotal.sarBEsariPercentS[value]);
        params[35].push(optionsTotal.sarBEsariPercentB[value]);
        params[36].push(optionsTotal.sarBEsariPercentL[value]);
        params[37].push(optionsTotal.sarBEsariDaily[value]);
        params[38].push(optionsTotal.pooshesh[value]);
        params[39].push(optionsTotal.ahromS[value]);
        params[40].push(optionsTotal.ahromB[value]);
        params[41].push(optionsTotal.ahromL[value]);
        params[42].push(optionsTotal.base[value]);
        params[43].push(optionsTotal.month[value]);
        params[44].push(optionsTotal.baseIsin[value]);
        params[45].push(optionsTotal.groupId[value]);
        params[46].push(optionsTotal.bazar[value]);
        params[47].push(optionsTotal.tazmin[value]);
        params[48].push(optionsTotal.inSood[value]);
        params[49].push(optionsTotal.Delta[value]);
        params[50].push(optionsTotal.Theta[value]);
        params[51].push(optionsTotal.Rho[value]);
        params[52].push(optionsTotal.Gamma[value]);
        params[53].push(optionsTotal.Vega[value]);
        params[54].push(optionsTotal.Black[value]);
        params[55].push(optionsTotal.coveredCall[value]);
        params[56].push(optionsTotal.coveredCall_m[value]);
        params[57].push(optionsTotal.coveredCall_y[value]);
    })

    // console.log(params)

    var chartData= [];
    for (let i=0; i<10; i++){
        if (options[2].value[i]<50)
            var y = 200;
        else
            var y = options[2].value[i]
        chartData[i] = {
          x: options[2].name[i],
          y: y
        }
        if (Math.round(Math.random()))
            chartData[i].fillColor = "#38c95f"
        else
            chartData[i].fillColor = "#e83535"
    }

    var result = {
        options : options,
        chartData : chartData,
        params : params
    }

    res.json(result);
}

// const deleteUser = async (req, res) => {
//     if (!req?.body?.id) return res.status(400).json({ "message": 'User ID required' });
//     const user = await User.findOne({ _id: req.body.id }).exec();
//     if (!user) {
//         return res.status(204).json({ 'message': `User ID ${req.body.id} not found` });
//     }
//     const result = await user.deleteOne({ _id: req.body.id });
//     res.json(result);
// }

const getOption = async (req, res) => {
    if (!req?.params?.id) return res.status(400).json({ "message": 'Option ID required' });
    const option = await Option.findOne({ ic: req.params.id }).exec();
    if (!option) {
        return res.status(204).json({ 'message': `Option ID ${req.params.id} not found` });
    }
    res.json(option);
}

module.exports = {
    getAllOptions,
    getSortOptions,
    getOption,
    saveData
}