const Option = require('../model/Option');

var OptionsZ = ['ضارش','ضهرم', 'ضبتهران', 'ضبرک', 'ضبساما', 'ضهین', 'ضپلا', 'ضترو', 'ضرول', 'ضتفارس', 'ضتوان', 'ضجهش', 'ضحآفرین', 'ضحریل', 'ضخاور', 'ضهمن', 'ضخپارس', 'ضسپا', 'ضستر', 'ضران', 'ضخود', 'ضدار', 'ضدرا', 'ضدی', 'ضذوب', 'ضرویین', 'ضسرو', 'ضسلا', 'ضبدر', 'ضشنا',  'ضتاب', 'ضستا','ضخوز', 'ضفرابورس', 'ضفصبا', 'ضملی', 'ضفلا', 'ضکاریس', 'ضکرمان', 'ضکوثر', 'ضلبخند', 'ضموج', 'ضنطرین', 'ضنوین', 'ضصاد', 'ضملت', 'ضجار', 'ضغدی', 'ضهای', 'ضهم'];


// const JDate = require('jalali-date');

const saveData = async (req, res) => {
    const resultFilter = req.body;

    const newOption = new Option;

    newOption.name=resultFilter.name;
    newOption.isin=resultFilter.isin;
    newOption.ic=resultFilter.ic;
    newOption.hoqBuy=resultFilter.hoqBuy;
    newOption.haqBuy=resultFilter.haqBuy;
    newOption.hoqSell=resultFilter.hoqSell;
    newOption.haqSell=resultFilter.haqSell;
    newOption.ppercent=resultFilter.ppercent;
    newOption.pprice=resultFilter.pprice;
    newOption.lprice=resultFilter.lprice;
    newOption.lpercent=resultFilter.lpercent;
    newOption.vol=resultFilter.vol;
    newOption.openPositions=resultFilter.openPositions;
    newOption.days=resultFilter.days;
    newOption.emal=resultFilter.emal;
    newOption.situation=resultFilter.situation;
    newOption.firstSell=resultFilter.firstSell;
    newOption.firstBuy=resultFilter.firstBuy;
    newOption.orders=resultFilter.orders;
    newOption.minPrice=resultFilter.minPrice;
    newOption.maxPrice=resultFilter.maxPrice;
    newOption.yesterday=resultFilter.yesterday;
    newOption.contractSize=resultFilter.contractSize;
    // newOption.saraneBuyV=resultFilter.saraneBuyV;
    // newOption.saraneSellV=resultFilter.saraneSellV;
    // newOption.saraneBuyP=resultFilter.saraneBuyP;
    // newOption.saraneSellP=resultFilter.saraneSellP;
    newOption.Bpercent=resultFilter.Bpercent;
    newOption.Spercent=resultFilter.Spercent;
    newOption.minpercent=resultFilter.minpercent;
    newOption.maxpercent=resultFilter.maxpercent;
    newOption.sarBEsariPriceS=resultFilter.sarBEsariPriceS;
    newOption.sarBEsariPriceB=resultFilter.sarBEsariPriceB;
    newOption.sarBEsariPriceL=resultFilter.sarBEsariPriceL;
    newOption.sarBEsariPercentS=resultFilter.sarBEsariPercentS;
    newOption.sarBEsariPercentB=resultFilter.sarBEsariPercentB;
    newOption.sarBEsariPercentL=resultFilter.sarBEsariPercentL;
    newOption.sarBEsariDaily=resultFilter.sarBEsariDaily;
    newOption.ahromS=resultFilter.ahromS;
    newOption.ahromB=resultFilter.ahromB;
    newOption.ahromL=resultFilter.ahromL;
    newOption.base=resultFilter.base;
    newOption.month=resultFilter.month;
    newOption.baseIsin=resultFilter.baseIsin;
    newOption.groupId=resultFilter.groupId;
    newOption.bazar=resultFilter.bazar;
    newOption.inSood=resultFilter.inSood;
    newOption.Delta=resultFilter.Delta;
    newOption.Theta=resultFilter.Theta;
    newOption.Rho=resultFilter.Rho;
    newOption.Gamma=resultFilter.Gamma;
    newOption.Vega=resultFilter.Vega;
    newOption.Black=resultFilter.Black;
    newOption.blackPercent=resultFilter.blackPercent;
    newOption.time=resultFilter.time;
    newOption.fullName=resultFilter.fullName;
    // newOption.pooshesh=resultFilter.pooshesh;
    // newOption.tazmin=resultFilter.tazmin;
    // newOption.coveredCall=resultFilter.coveredCall;
    // newOption.coveredCall_m=resultFilter.coveredCall_m;
    // newOption.coveredCall_y=resultFilter.coveredCall_y;

    newOption.save();

    res.json("ok");
}


const getAllOptions = async (req, res) => {
    const options = await Option.find();
    if (!options) return res.status(204).json({ 'message': 'No option found' });
    res.json(options);
}

const getSortOptions = async (req, res) => {
    const { settings } = req.body;
    const Settings = JSON.parse(settings);

    // const jdate = new JDate;
    // const jdate = new JDate.toJalali(new Date("2024,04,24"))
    // console.log(jdate)

    const optionsTotal2 = await Option.find().sort({_id:-1}).limit(2); //.findOne();
    const optionsTotal = optionsTotal2[0];
    if (!optionsTotal) return res.status(204).json({ 'message': 'No option found' });
    
    var Parameters = Array.from(Array(12), () => new Array(0));
    var Index = Array.from(Array(12), () => new Array(0));
    var nFilter = 12;

    Parameters[0]=optionsTotal.sarBEsariPercentS;
    Parameters[1]=optionsTotal.sarBEsariDaily;
    Parameters[2]=optionsTotal.ahromS;
    Parameters[3]=optionsTotal.vol;
    Parameters[4]=optionsTotal.Spercent;
    Parameters[5]=optionsTotal.lpercent;
    Parameters[6]=optionsTotal.hoqSell;
    Parameters[7]=optionsTotal.openPositions;
    Parameters[8]=optionsTotal.days;
    Parameters[9]=optionsTotal.sarBEsariPercentB;
    Parameters[10]=optionsTotal.blackPercent;
    for (let i=0; i<Parameters[0].length; i++)
        if(optionsTotal.hoqSell[i]-optionsTotal2[1].hoqSell[i]>0)
            Parameters[11].push(optionsTotal.hoqSell[i])

    optionName=optionsTotal.name;
    var nOption = Parameters[0].length;
    var selectedOptions=[];

    var sortTypes = Settings.sort;

    for (let i=0; i<nFilter-1; i++)
        if (sortTypes[i])//soudi nozooli
            Index[i] = Array.from(Array(Parameters[i].length).keys()).sort((a, b) => Parameters[i][a] < Parameters[i][b] ? -1 : (Parameters[i][b] < Parameters[i][a]) | 0)
        else
            Index[i] = Array.from(Array(Parameters[i].length).keys()).sort((b, a) => Parameters[i][a] < Parameters[i][b] ? -1 : (Parameters[i][b] < Parameters[i][a]) | 0)


    // for (let i=0; i<nFilter; i++){
    //     for (let j=0; j<Parameters[i].length; j++)
    //         Index[i][j]=Math.round(Math.random()*Parameters[i].length);
    // }

    var remainedOptions=[];
    
    for(var i=0; i<nOption; i++){
        if (Settings.group[0]===false){
            var ok=true;
            for(var g=1; g<Settings.group.length; g++){
                if(optionsTotal.groupId[i]===Settings.group[g]){
                    ok=false;
                    break;
                }
            }
            if(ok)
                remainedOptions.push(i);
        }
        if (Settings.paye[0]===false){
            var ok=true;
            for(var o=1; o<Settings.paye.length; o++){
                if(optionName[i].indexOf(OptionsZ[Settings.paye[o]-1])>-1){
                    ok=false;
                    break;
                }
            }
            if(ok)
                remainedOptions.push(i);
        }
        if (Settings.month[0]===false){
            var ok=true;
            for(var m=1; m<Settings.month.length; m++){
                if(Settings.month[m]===optionsTotal.month[i]){
                    ok=false;
                    break;
                }
            }
            if(ok)
                remainedOptions.push(i);
        }
        if (Settings.call===false)        
            if(optionName[i].indexOf("ض")===0){
                remainedOptions.push(i);
                continue;
            }
        if (Settings.put===false)        
            if(optionName[i].indexOf("ط")===0){
                remainedOptions.push(i);
                continue;
            }
        if (Settings.vPlus)
            if(optionsTotal.vol[i]===0){
                remainedOptions.push(i);
                continue;
            }
        if (Settings.inSood)
            if(optionsTotal.inSood[i]===false){
                remainedOptions.push(i);
                continue;
            }
        if (Settings.emalDay)
            if(optionsTotal.days[i]>0){
                remainedOptions.push(i);
                continue;
            }
        if (Settings.minAhrom!=='')
            if(optionsTotal.ahromS[i]<Number(Settings.minAhrom)){
                remainedOptions.push(i);
                continue;
            }
        if (Settings.maxAhrom!=='')
            if(optionsTotal.ahromS[i]>Number(Settings.maxAhrom)){
                remainedOptions.push(i);
                continue;
            }
        if (Settings.minSarDaily!=='')
            if(optionsTotal.sarBEsariDaily[i]<Number(Settings.minSarDaily)){
                remainedOptions.push(i);
                continue;
            }
        if (Settings.maxSarDaily!=='')
            if(optionsTotal.sarBEsariDaily[i]>Number(Settings.maxSarDaily)){
                remainedOptions.push(i);
                continue;
            }
        if (Settings.minSarTotal!=='')
            if(optionsTotal.sarBEsariPercentS[i]<Number(Settings.minSarTotal)){
                remainedOptions.push(i);
                continue;
            }
        if (Settings.maxSarTotal!=='')
            if(optionsTotal.sarBEsariPercentS[i]>Number(Settings.maxSarTotal)){
                remainedOptions.push(i);
                continue;
            }
        // if (Settings.minEmal!=='')
        //     if(optionsTotal.emal[i]<Number(Settings.minEmal)){
        //         remainedOptions.push(i);
        //         continue;
        //     }
        // if (Settings.maxEmal!=='')
        //     if(optionsTotal.emal[i]>Number(Settings.maxEmal)){
        //         remainedOptions.push(i);
        //         continue;
        //     }
    }

    console.log(remainedOptions.length)

    // filter output options
    var options=[];
    for(var filter=0; filter<nFilter; filter++){
        var name=[];
        var value=[];
        var percent=[];
        
        // check settings
        for (var s in Settings.minmax){

            // if(Settings.minmax[s].id === String("minF"+(filter+1))){
            //     if (Settings.minmax[s].value === '')
                    var min = -Infinity;
            //     else
            //         var min = Settings.minmax[s].value;
            // }

            // if(Settings.minmax[s].id === String("maxF"+(filter+1))){
            //     if (Settings.minmax[s].value === '')
                    var max = Infinity;
            //     else
            //         var max = Settings.minmax[s].value;
            // }
        }

        for (let i=0; i<nOption; i++){
            let index = Index[filter][i];
            if(remainedOptions.indexOf(index)>-1)
                continue;
            if (Parameters[filter][index] >= min && Parameters[filter][index] <= max && Parameters[filter][index]!==null){
                name.push(optionName[Index[filter][i]]);
                value.push(Parameters[filter][Index[filter][i]]);
                if(filter===0)
                    percent.push(optionsTotal.ahromS[Index[filter][i]])
                else
                    percent.push(Parameters[0][Index[filter][i]])
                selectedOptions.push(Index[filter][i]);
            }
            if (name.length>=10)
                break;
        }

        options[filter]={
            name: name,
            value: value,
            percent:percent
        }
    }
    selectedOptions = selectedOptions.filter((e, i, a) => a.indexOf(e) === i);

    var params = Array.from(Array(58), () => new Array(0));

    selectedOptions.map((value)=>{
        params[0].push(optionsTotal.name[value]);
        params[1].push(optionsTotal.isin[value]);
        params[2].push(optionsTotal.ic[value]);
        params[3].push(optionsTotal.hoqBuy[value]);
        params[4].push(optionsTotal.haqBuy[value]);
        params[5].push(optionsTotal.hoqSell[value]);
        params[6].push(optionsTotal.haqSell[value]);
        params[7].push(optionsTotal.ppercent[value]);
        params[8].push(optionsTotal.pprice[value]);
        params[9].push(optionsTotal.lprice[value]);
        params[10].push(optionsTotal.lpercent[value]);
        params[11].push(optionsTotal.vol[value]);
        params[12].push(optionsTotal.openPositions[value]);
        params[13].push(optionsTotal.days[value]);
        params[14].push(optionsTotal.emal[value]);
        params[15].push(optionsTotal.situation[value]);
        params[16].push(optionsTotal.firstSell[value]);
        params[17].push(optionsTotal.firstBuy[value]);
        params[18].push(optionsTotal.orders[value]);
        params[19].push(optionsTotal.minPrice[value]);
        params[20].push(optionsTotal.maxPrice[value]);
        params[21].push(optionsTotal.yesterday[value]);
        params[22].push(optionsTotal.contractSize[value]);
        // params[23].push(optionsTotal.saraneBuyV[value]);
        // params[24].push(optionsTotal.saraneSellV[value]);
        params[25].push(optionsTotal.contractSize[value]);
        params[26].push(optionsTotal.emal[value]);
        params[27].push(optionsTotal.Bpercent[value]);
        params[28].push(optionsTotal.Spercent[value]);
        params[29].push(optionsTotal.minpercent[value]);
        params[30].push(optionsTotal.maxpercent[value]);
        params[31].push(optionsTotal.sarBEsariPriceS[value]);
        params[32].push(optionsTotal.sarBEsariPriceB[value]);
        params[33].push(optionsTotal.sarBEsariPriceL[value]);
        params[34].push(optionsTotal.sarBEsariPercentS[value]);
        params[35].push(optionsTotal.sarBEsariPercentB[value]);
        params[36].push(optionsTotal.sarBEsariPercentL[value]);
        params[37].push(optionsTotal.sarBEsariDaily[value]);
        params[38].push(optionsTotal.blackPercent[value]);
        params[39].push(optionsTotal.ahromS[value]);
        params[40].push(optionsTotal.ahromB[value]);
        params[41].push(optionsTotal.ahromL[value]);
        params[42].push(optionsTotal.base[value]);
        params[43].push(optionsTotal.month[value]);
        params[44].push(optionsTotal.baseIsin[value]);
        params[45].push(optionsTotal.groupId[value]);
        params[46].push(optionsTotal.bazar[value]);
        params[47].push(optionsTotal.bazar[value]);//fullName
        params[48].push(optionsTotal.inSood[value]);
        params[49].push(optionsTotal.Delta[value]);
        params[50].push(optionsTotal.Theta[value]);
        params[51].push(optionsTotal.Rho[value]);
        params[52].push(optionsTotal.Gamma[value]);
        params[53].push(optionsTotal.Vega[value]);
        params[54].push(optionsTotal.Black[value]);
        params[55].push(optionsTotal.minpercent[value]);
        params[56].push(optionsTotal.maxpercent[value]);
    })
    params[57]=optionsTotal.time;

    // console.log(params)

    var chartData= [];
    for (let i=0; i<10; i++){
        if (options[2].value[i]<50)
            var y = 200;
        else
            var y = options[2].value[i]
        chartData[i] = {
          x: options[2].name[i],
          y: y
        }
        if (Math.round(Math.random()))
            chartData[i].fillColor = "#38c95f"
        else
            chartData[i].fillColor = "#e83535"
    }

    var result = {
        options : options,
        chartData : chartData,
        params : params
    }

    res.json(result);
}

// const deleteUser = async (req, res) => {
//     if (!req?.body?.id) return res.status(400).json({ "message": 'User ID required' });
//     const user = await User.findOne({ _id: req.body.id }).exec();
//     if (!user) {
//         return res.status(204).json({ 'message': `User ID ${req.body.id} not found` });
//     }
//     const result = await user.deleteOne({ _id: req.body.id });
//     res.json(result);
// }

const getOption = async (req, res) => {
    // console.log(req?.params?.id)
    // if (!req?.params?.id) return res.status(400).json({ "message": 'Option ID required' });
    // const option = await Option.findOne({ ic: req.params.id }).exec();
    // if (!option) {
    //     return res.status(204).json({ 'message': `Option ID ${req.params.id} not found` });
    // }
    // const optionsTotal2 = await Option.find().sort({_id:-1}).limit(1);
    // const optionsTotal = optionsTotal2[0];
    // if (!optionsTotal) return res.status(204).json({ 'message': 'No option found' });
    // var ic = optionsTotal.ic;
    // var index = ic.indexOf(req.params.id);
    
    // var params = Array.from(Array(58), () => new Array(0));

    // if(index>-1){

    // params[0].push(optionsTotal.name[index]);
    // params[1].push(optionsTotal.isin[index]);
    // params[2].push(optionsTotal.ic[index]);
    // params[3].push(optionsTotal.hoqBuy[index]);
    // params[4].push(optionsTotal.haqBuy[index]);
    // params[5].push(optionsTotal.hoqSell[index]);
    // params[6].push(optionsTotal.haqSell[index]);
    // params[7].push(optionsTotal.ppercent[index]);
    // params[8].push(optionsTotal.pprice[index]);
    // params[9].push(optionsTotal.lprice[index]);
    // params[10].push(optionsTotal.lpercent[index]);
    // params[11].push(optionsTotal.vol[index]);
    // params[12].push(optionsTotal.openPositions[index]);
    // params[13].push(optionsTotal.days[index]);
    // params[14].push(optionsTotal.emal[index]);
    // params[15].push(optionsTotal.situation[index]);
    // params[16].push(optionsTotal.firstSell[index]);
    // params[17].push(optionsTotal.firstBuy[index]);
    // params[18].push(optionsTotal.orders[index]);
    // params[19].push(optionsTotal.minPrice[index]);
    // params[20].push(optionsTotal.maxPrice[index]);
    // params[21].push(optionsTotal.yesterday[index]);
    // params[22].push(optionsTotal.contractSize[index]);
    // // params[23].push(optionsTotal.saraneBuyV[index]);
    // // params[24].push(optionsTotal.saraneSellV[index]);
    // params[25].push(optionsTotal.contractSize[index]);
    // params[26].push(optionsTotal.emal[index]);
    // params[27].push(optionsTotal.Bpercent[index]);
    // params[28].push(optionsTotal.Spercent[index]);
    // params[29].push(optionsTotal.minpercent[index]);
    // params[30].push(optionsTotal.maxpercent[index]);
    // params[31].push(optionsTotal.sarBEsariPriceS[index]);
    // params[32].push(optionsTotal.sarBEsariPriceB[index]);
    // params[33].push(optionsTotal.sarBEsariPriceL[index]);
    // params[34].push(optionsTotal.sarBEsariPercentS[index]);
    // params[35].push(optionsTotal.sarBEsariPercentB[index]);
    // params[36].push(optionsTotal.sarBEsariPercentL[index]);
    // params[37].push(optionsTotal.sarBEsariDaily[index]);
    // params[38].push(optionsTotal.blackPercent[index]);
    // params[39].push(optionsTotal.ahromS[index]);
    // params[40].push(optionsTotal.ahromB[index]);
    // params[41].push(optionsTotal.ahromL[index]);
    // params[42].push(optionsTotal.base[index]);
    // params[43].push(optionsTotal.month[index]);
    // params[44].push(optionsTotal.baseIsin[index]);
    // params[45].push(optionsTotal.groupId[index]);
    // params[46].push(optionsTotal.bazar[index]);
    // params[47].push(optionsTotal.bazar[index]);//fullName
    // params[48].push(optionsTotal.inSood[index]);
    // params[49].push(optionsTotal.Delta[index]);
    // params[50].push(optionsTotal.Theta[index]);
    // params[51].push(optionsTotal.Rho[index]);
    // params[52].push(optionsTotal.Gamma[index]);
    // params[53].push(optionsTotal.Vega[index]);
    // params[54].push(optionsTotal.Black[index]);
    // params[55].push(optionsTotal.minpercent[index]);
    // params[56].push(optionsTotal.maxpercent[index]);
    // params[57]=optionsTotal.time;
    // }

    res.render('option', {
        data: "72021468910907360"
    })
}

const getOption2 = async (req, res) => {

    // console.log(req?.params?.id)
    // if (!req?.params?.id) return res.status(400).json({ "message": 'Option ID required' });
    // const option = await Option.findOne({ ic: req.params.id }).exec();
    // if (!option) {
    //     return res.status(204).json({ 'message': `Option ID ${req.params.id} not found` });
    // }
    const optionsTotal2 = await Option.find().sort({_id:-1}).limit(1);
    const optionsTotal = optionsTotal2[0];
    if (!optionsTotal) return res.status(204).json({ 'message': 'No option found' });
    var ic = optionsTotal.ic;
    var index = ic.indexOf(req.params.id);
    
    var params = Array.from(Array(58), () => new Array(0));

    if(index>-1){

    params[0].push(optionsTotal.name[index]);
    params[1].push(optionsTotal.isin[index]);
    params[2].push(optionsTotal.ic[index]);
    params[3].push(optionsTotal.hoqBuy[index]);
    params[4].push(optionsTotal.haqBuy[index]);
    params[5].push(optionsTotal.hoqSell[index]);
    params[6].push(optionsTotal.haqSell[index]);
    params[7].push(optionsTotal.ppercent[index]);
    params[8].push(optionsTotal.pprice[index]);
    params[9].push(optionsTotal.lprice[index]);
    params[10].push(optionsTotal.lpercent[index]);
    params[11].push(optionsTotal.vol[index]);
    params[12].push(optionsTotal.openPositions[index]);
    params[13].push(optionsTotal.days[index]);
    params[14].push(optionsTotal.emal[index]);
    params[15].push(optionsTotal.situation[index]);
    params[16].push(optionsTotal.firstSell[index]);
    params[17].push(optionsTotal.firstBuy[index]);
    params[18].push(optionsTotal.orders[index]);
    params[19].push(optionsTotal.minPrice[index]);
    params[20].push(optionsTotal.maxPrice[index]);
    params[21].push(optionsTotal.yesterday[index]);
    params[22].push(optionsTotal.contractSize[index]);
    // params[23].push(optionsTotal.saraneBuyV[index]);
    // params[24].push(optionsTotal.saraneSellV[index]);
    params[25].push(optionsTotal.contractSize[index]);
    params[26].push(optionsTotal.emal[index]);
    params[27].push(optionsTotal.Bpercent[index]);
    params[28].push(optionsTotal.Spercent[index]);
    params[29].push(optionsTotal.minpercent[index]);
    params[30].push(optionsTotal.maxpercent[index]);
    params[31].push(optionsTotal.sarBEsariPriceS[index]);
    params[32].push(optionsTotal.sarBEsariPriceB[index]);
    params[33].push(optionsTotal.sarBEsariPriceL[index]);
    params[34].push(optionsTotal.sarBEsariPercentS[index]);
    params[35].push(optionsTotal.sarBEsariPercentB[index]);
    params[36].push(optionsTotal.sarBEsariPercentL[index]);
    params[37].push(optionsTotal.sarBEsariDaily[index]);
    params[38].push(optionsTotal.blackPercent[index]);
    params[39].push(optionsTotal.ahromS[index]);
    params[40].push(optionsTotal.ahromB[index]);
    params[41].push(optionsTotal.ahromL[index]);
    params[42].push(optionsTotal.base[index]);
    params[43].push(optionsTotal.month[index]);
    params[44].push(optionsTotal.baseIsin[index]);
    params[45].push(optionsTotal.groupId[index]);
    params[46].push(optionsTotal.bazar[index]);
    params[47].push(optionsTotal.bazar[index]);//fullName
    params[48].push(optionsTotal.inSood[index]);
    params[49].push(optionsTotal.Delta[index]);
    params[50].push(optionsTotal.Theta[index]);
    params[51].push(optionsTotal.Rho[index]);
    params[52].push(optionsTotal.Gamma[index]);
    params[53].push(optionsTotal.Vega[index]);
    params[54].push(optionsTotal.Black[index]);
    params[55].push(optionsTotal.minpercent[index]);
    params[56].push(optionsTotal.maxpercent[index]);
    params[57]=optionsTotal.time;
    }

    var result = {
        params : params
    }

    res.json(result);

}

module.exports = {
    getAllOptions,
    getSortOptions,
    getOption,
    getOption2,
    saveData
}