const express = require('express');
const router = express.Router();
const path = require('path');

// const User = require('../model/User');
const Option = require('../model/Option');



router.get('^/$|/index(.html)?', (req, res) => {

    // res.sendFile(path.join(__dirname, '..', 'views', 'index.html'));

    // const getAllUsers = async () => {
    //     const users = await User.findOne();
    //     res.render('index', {
    //         data: users
    //     })
    // }

    var Namads=['ارزش','اهرم', 'بتهران', 'برکت', 'بساما', 'بهین رو', 'پالایش', 'پتروآگاه', 'پترول', 'تفارس', 'توان', 'جهش', 'حآفرین', 'حریل', 'خاور', 'خبهمن', 'خپارس', 'خساپا', 'خگستر', 'خودران', 'خودرو', 'دارا یکم', 'دریا', 'دی', 'ذوب', 'رویین', 'سرو', 'سلام', 'شبندر', 'شپنا', 'شتاب', 'شستا', 'فخوز', 'فرابورس', 'فصبا', 'فملی', 'فولاد', 'کاریس', 'کرمان', 'کوثر', 'لبخند', 'موج', 'نطرین', 'نوین', 'وبصادر', 'وبملت', 'وتجارت', 'وکغدیر', 'های وب', 'هم وزن'];

    // var group = ['خودرویی','بانک و بیمه','پالایشی/پترو','فلزات','صندوق','سرمایه‌گذاری','سایر']

    var filterTitles = ['% سربه‌سری فروشنده ','% سربه‌سری روزانه ','اهرم فروشنده','حجم معامله','درصد اردر فروشنده','درصد اردر خریدار','حجم فروش حقوقی','تعداد موقعیت','روز باقیمانده','سربه‌سری خریدار','%تفاوت با منصفانه','آخرین حقوقی']

    
    // Option.find({}, function(err, options){
    //     // console.log("this is: ", options)
    //     res.render('index', {
    //         data: options
    //     })
    // })

    res.render('index', {
        data: Namads,
        filterTitles: filterTitles
    })
        
});

module.exports = router;