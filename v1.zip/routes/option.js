const express = require('express');
const router = express.Router();
const path = require('path');

// const User = require('../model/User');
const Option = require('../model/Option');



router.get('/', (req, res) => {

    // const getAllUsers = async () => {
    // const optionsTotal2 = await Option.find().sort({_id:-1}).limit(1);
    // const optionsTotal = optionsTotal2[0];
    // if (!optionsTotal) return res.status(204).json({ 'message': 'No option found' });
    // // var ic = optionsTotal.ic;
    // // var index = ic.indexOf(req.params.id);
    
    // var params = Array.from(Array(58), () => new Array(1));

    // if(index>-1){

    // params[0].push(optionsTotal.name[index]);
    // params[1].push(optionsTotal.isin[index]);
    // params[2].push(optionsTotal.ic[index]);
    // params[3].push(optionsTotal.hoqBuy[index]);
    // params[4].push(optionsTotal.haqBuy[index]);
    // params[5].push(optionsTotal.hoqSell[index]);
    // params[6].push(optionsTotal.haqSell[index]);
    // params[7].push(optionsTotal.ppercent[index]);
    // params[8].push(optionsTotal.pprice[index]);
    // params[9].push(optionsTotal.lprice[index]);
    // params[10].push(optionsTotal.lpercent[index]);
    // params[11].push(optionsTotal.vol[index]);
    // params[12].push(optionsTotal.openPositions[index]);
    // params[13].push(optionsTotal.days[index]);
    // params[14].push(optionsTotal.emal[index]);
    // params[15].push(optionsTotal.situation[index]);
    // params[16].push(optionsTotal.firstSell[index]);
    // params[17].push(optionsTotal.firstBuy[index]);
    // params[18].push(optionsTotal.orders[index]);
    // params[19].push(optionsTotal.minPrice[index]);
    // params[20].push(optionsTotal.maxPrice[index]);
    // params[21].push(optionsTotal.yesterday[index]);
    // params[22].push(optionsTotal.contractSize[index]);
    // // params[23].push(optionsTotal.saraneBuyV[index]);
    // // params[24].push(optionsTotal.saraneSellV[index]);
    // params[25].push(optionsTotal.contractSize[index]);
    // params[26].push(optionsTotal.emal[index]);
    // params[27].push(optionsTotal.Bpercent[index]);
    // params[28].push(optionsTotal.Spercent[index]);
    // params[29].push(optionsTotal.minpercent[index]);
    // params[30].push(optionsTotal.maxpercent[index]);
    // params[31].push(optionsTotal.sarBEsariPriceS[index]);
    // params[32].push(optionsTotal.sarBEsariPriceB[index]);
    // params[33].push(optionsTotal.sarBEsariPriceL[index]);
    // params[34].push(optionsTotal.sarBEsariPercentS[index]);
    // params[35].push(optionsTotal.sarBEsariPercentB[index]);
    // params[36].push(optionsTotal.sarBEsariPercentL[index]);
    // params[37].push(optionsTotal.sarBEsariDaily[index]);
    // params[38].push(optionsTotal.blackPercent[index]);
    // params[39].push(optionsTotal.ahromS[index]);
    // params[40].push(optionsTotal.ahromB[index]);
    // params[41].push(optionsTotal.ahromL[index]);
    // params[42].push(optionsTotal.base[index]);
    // params[43].push(optionsTotal.month[index]);
    // params[44].push(optionsTotal.baseIsin[index]);
    // params[45].push(optionsTotal.groupId[index]);
    // params[46].push(optionsTotal.bazar[index]);
    // params[47].push(optionsTotal.bazar[index]);//fullName
    // params[48].push(optionsTotal.inSood[index]);
    // params[49].push(optionsTotal.Delta[index]);
    // params[50].push(optionsTotal.Theta[index]);
    // params[51].push(optionsTotal.Rho[index]);
    // params[52].push(optionsTotal.Gamma[index]);
    // params[53].push(optionsTotal.Vega[index]);
    // params[54].push(optionsTotal.Black[index]);
    // params[55].push(optionsTotal.minpercent[index]);
    // params[56].push(optionsTotal.maxpercent[index]);
    // params[57]=optionsTotal.time;
    // }

    // res.render('option', {
    //     data: params
    // })
// }

})

        

module.exports = router;